Palworld map is a fan Palworld project that provides a webpage with a map that helps in localising various points of interest in Palworld.

Please support the Palworld developer - [Pocketpair](https://www.pocketpair.jp/palworld)!